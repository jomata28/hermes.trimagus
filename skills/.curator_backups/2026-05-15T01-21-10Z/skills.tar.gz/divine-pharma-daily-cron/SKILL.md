---
name: divine-pharma-daily-cron
description: Daily Divine Intervention Pharmacology podcast processing - fetches latest episode, transcribes, extracts insights, creates Obsidian notes
version: 1.0.0
author: Hermes Agent
category: productivity
---

# Divine Intervention Pharmacology Daily Processor

This skill automates the daily processing of Divine Intervention Pharmacology podcast episodes for USMLE-style study notes in Obsidian.

## Workflow

1. **Notion Query**: Fetch latest episode from D.I. PHARM PODCASTS database
2. **Audio Processing**: Download MP3 and transcribe with Whisper
3. **Content Extraction**: Use LLM to identify key pharmacological concepts
4. **Obsidian Integration**: Create formatted daily note with template structure
5. **Notification**: Send Telegram alert with Obsidian URI

## Required Tools

- `notion`: For querying the podcast database
- `terminal`: For downloading podcast audio (curl) and file operations
- `mlops/whisper`: For audio transcription (may fail in resource-constrained environments)
- `obsidian`: For creating/updating vault notes
- `file_tools`: For HTML parsing when needed (via execute_code)

## Environment Variables

- `NOTION_API_KEY`: Notion integration token
- `OBSIDIAN_VAULT_PATH`: Path to Divine Pharmacology vault (default: `/root/Divine-Pharmacology`)

Note: Environment variables are loaded from `~/.hermes/.env` if present, otherwise from system environment.

## Processing Steps

### 1. Database Query
Queries the Notion database for the most recent episode by checking:
- Uses database ID: `2f88c883-85ba-81d3-a9d2-eca5f4e30d0b` (the database, not the data_source)
- Requires Notion API version `2022-06-28` for querying (version `2025-09-03` fails with invalid_request_url)
- Uses sort format: `{"timestamp": "created_time", "direction": "descending"}` (property sort fails with validation_error)
- Alternative approach: Fetch all records (page_size=100) and sort by created_time descending in code
- Checks properties: `Link` (URL), `Title` (episode title), `Related Topic` (categorization)
- Working query: POST to `/v1/databases/{database_id}/query` with Notion-Version: 2022-06-28

### 2. Audio Processing
- Falls back to basic note structure if transcription fails due to resource constraints
- Saves transcription temporarily for processing when successful
- Uses HTML parsing to extract MP3 URL from episode page when direct browser tools unavailable

### 3. Pharmacological Extraction
Uses LLM analysis to identify key pharmacological concepts from transcription:
- Key lessons and explained concepts
- Drug mechanisms and classifications
- New drugs mentioned with mechanisms
- System-level connections (RAAS, autonomic, etc.)
- Clinical vignettes and patient cases
- USMLE high-yield facts and mnemonics
- Comprehension questions (clinical + mechanism-based)
- Falls back to basic structure if transcription unavailable, extracting minimal info from episode title/link

### 4. Obsidian Note Creation
Formats content using the Daily-Session template:
- Frontmatter with date, podcast info, duration, and processing status
- Key Lessons section (verbatim-arranged for readability when transcription successful, placeholder when failed)
- Mechanisms Explained (detailed pathways)
- Drug Connections (new, system, previous links)
- Comprehension Questions (3-5 mixed clinical/mechanism)
- USMLE High-Yield Points (prioritized automatically)
- Evening Review Preview (teaser for next day)
- Handles transcription failures gracefully by creating structured note with placeholders

### 5. Delivery
- Creates/updates note in `Daily-Sessions/YYYY-MM-DD-Topic.md`
- Sends Telegram message with:
  - Episode title and topic
  - Key takeaway summary
  - Obsidian URI: `obsidian://open?vault=Divine-Pharmacology&file=Daily-Sessions/{{date}}.md`

## Usage

This skill is designed to be run via Hermes cron job:
- Schedule: `0 7 * * *` (7:00 AM CST daily)
- Delivery: `telegram` (to user's home channel)
- Model: Current main provider (for consistency)

## Error Handling

- Skips if episode already processed today
- Retries failed downloads up to 3 times
- Falls back to summary-only if transcription fails
- Preserves existing notes if processing fails mid-pipeline
