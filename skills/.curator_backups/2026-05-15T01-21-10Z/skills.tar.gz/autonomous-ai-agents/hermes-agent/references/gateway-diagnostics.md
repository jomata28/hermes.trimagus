# Gateway Diagnostics & Repair Playbook

## Quick status check
```bash
hermes gateway status
hermes gateway setup    # shows which platforms are configured vs not
```

## Symptom: Telegram messages arrive erratically or "connection is broken"

Do NOT assume Telegram is down. Check logs *before* acting:
```bash
grep -i "telegram\|error\|failed\|timeout" ~/.hermes/logs/gateway.log | tail -30
```

**If you see `TimedOut` / `httpx.ReadError` but also `inbound message` and `response ready` pairs** — the connection is actually working; it's just reconnecting after transient network blips. The real failure is usually *downstream* (model fallback / bad model ID) and looks like:
```
ERROR root: Non-retryable client error: Error code: 400 - {'error': {'message': 'z-ai/glm-4-5-air:free is not a valid model ID', 'code': 400}}
```

**Repair sequence:**
1. Fix the model fallback — set a known-good model: `hermes config set model.default PROVIDER/MODEL`
2. Restart gateway: `hermes gateway restart`

## Symptom: model fallback 400 errors on OpenRouter

When the primary model fails, Hermes falls back through the credential pool. A bad fallback model ID (e.g. `z-ai/glm-4-5-air:free` which OpenRouter rejected) will return 400 and break responses even though Telegram is connected.

Fix: explicitly set `model.default` to a model known to work on OpenRouter at that moment. Recent known-good examples: `moonshotai/kimi-k2.6`, `anthropic/claude-sonnet-4`, `qwen/qwen3-235b-a22b`.

## Symptom: Adding WhatsApp

1. Edit `.env` and set `WHATSAPP_ENABLED=true` (requires interactive access; agent cannot patch `.env` directly because it's credential-protected).
2. Run `hermes gateway setup` → select WhatsApp → scan QR code with phone (WhatsApp Linked Devices → Link a Device).
3. Restart gateway.

WhatsApp uses the built-in Baileys bridge — no external API key needed.

## Symptom: `Telegram bot token already in use (PID ...)` on restart

The old gateway process is still alive and holding the token. Kill it by PID, then start: `kill -9 <PID>; hermes gateway run`

## Symptom: WhatsApp messages rejected (allowlist_mismatch)

The WhatsApp bridge enforces an allowlist — if your number format doesn't match, all messages are silently dropped.

**Check:**
```bash
tail /root/.hermes/whatsapp/bridge.log | grep allowlist_mismatch
```

If you see `allowlist_mismatch` with sender IDs matching your phone number, the number format is wrong. WhatsApp Mexico (+52) changed numbering — old format was `52` + 10 digits, new format is `521` + 10 digits.

**Fix:**
1. Update allowlist: `hermes config set whatsapp.allowed_users "521XXXXXXXXXX"`
2. Restart gateway: `hermes gateway restart`
3. Verify bridge picked it up: check bridge.log for new messages without `allowlist_mismatch`

**Pitfall:** The gateway config change in `config.yaml` only applies after the gateway restarts. The bridge runs as a separate Node process and needs to be killed + restarted for the new config to take effect.

## Symptom: WhatsApp bridge.js died silently

The gateway log says "✓ whatsapp connected" but no messages come through. Check the actual Node bridge:
```bash
pgrep -fa 'bridge.js'
```

If no output, the bridge process is dead. The gateway won't auto-restart it.

**Fix:**
```bash
node /root/.hermes/hermes-agent/scripts/whatsapp-bridge/bridge.js --port 3000 --session /root/.hermes/whatsapp/session --mode bot
```

Then check the bridge log:
```bash
tail -5 /root/.hermes/whatsapp/bridge.log
```

Look for "✅ WhatsApp connected!" and verify new messages aren't being rejected.

## Restricted work computers — accessing VPS without local SSH

When the user is on a locked-down work machine (cannot install SSH client, cannot run tunnels), but needs to interact with their VPS:

**Hostinger VPS:**
1. Go to hpanel.hostinger.com
2. Click "VPS" → select the VPS
3. Look for "Browser Terminal" or "Console" in the sidebar
4. This opens a terminal directly in the browser — works on any locked-down machine
5. Login as root and run commands (e.g. `hermes whatsapp`)

**Alternative:** Any cloud dashboard (DigitalOcean, Linode, etc.) has a browser console option.

## Dashboard over SSH — when the user has only a browser (work computer, no local CLI)

If the user cannot run an SSH tunnel (`ssh -L`) locally (e.g. work-locked machine, only a browser):

1. **Option A: SSH tunnel from the server side** — not viable; tunnels must originate client-side.
2. **Option B: Bind the dashboard to 0.0.0.0** (default is 127.0.0.1, unreachable from outside). ⚠️ Exposes API keys in the dashboard UI.
   ```bash
   hermes dashboard --stop
   hermes dashboard --insecure --host 0.0.0.0 --no-open
   ```
   Then access `http://<vps-ip>:9119` from any browser.
3. **Option C: ngrok** — safer than `--insecure` because you get a temporary public URL without opening a persistent public port.
   ```bash
   ngrok http 9119
   ```

**Pitfall:** Backgrounding `hermes dashboard` via the agent's `terminal(background=true)` works, but if the systemd/hermes service restarts the dashboard may get orphaned. Prefer `hermes dashboard --stop` + `hermes dashboard --insecure --host 0.0.0.0` as a long-running background process, or use `nohup` + `disown`.

**Pitfall:** `--insecure` shows raw API keys in the Config / `.env` tabs. Don't use it on shared/VPS hosts unless access to port 9119 is firewalled to your IP.

## Dashboard quick start

```bash
hermes dashboard              # http://localhost:9119
hermes dashboard --tui        # adds chat tab
hermes dashboard --stop       # kill
```

Dashboard shows: config, API keys, sessions, kanban board, plugins, skills.
