# Hermes Web Dashboard Reference

Entry point command: `hermes dashboard [flags]`

## Flags

| Flag | Default | Meaning |
|------|---------|---------|
| `--port` | `9119` | HTTP port |
| `--host` | `127.0.0.1` | Bind interface |
| `--no-open` | false | Skip `xdg-open`/`open` in browser |
| `--insecure` | false | Allow `0.0.0.0`/non-localhost (⚠️ exposes API keys) |
| `--tui` | false | Expose the in-browser Chat tab (embedded `hermes --tui` via PTY/WebSocket). Also set via `HERMES_DASHBOARD_TUI=1`. |
| `--stop` | — | SIGTERM all `hermes dashboard` processes (no PID file, scans process table) |
| `--status` | — | Print running dashboard PID or "not running" |

## What it shows

- Config editor (`config.yaml`)
- API keys / `.env` editor
- Session browser (search, export, rename, delete)
- Kanban board (via `plugins/kanban/dashboard/` — needs `dist/index.js`)
- Skills manager
- Plugin tabs (auto-discovered from `plugins/*/dashboard/manifest.json`)

## Plugin system

A plugin dashboard tab needs a `manifest.json`:

```json
{
  "name": "kanban",
  "label": "Kanban",
  "description": "...",
  "icon": "Package",
  "version": "1.0.0",
  "tab": {"path": "/kanban", "position": "after:skills"},
  "entry": "dist/index.js",
  "css": "dist/style.css",
  "api": "plugin_api.py"
}
```

The `api` Python file is mounted at `/api/plugins/<name>/` in the FastAPI app.

## Security notes

- Dashboard binds **localhost only** by default (--host 127.0.0.1).
- Plugin routes (/api/plugins/...) skip auth middleware — this is fine on localhost, dangerous on `--host 0.0.0.0`.
- WebSocket endpoints still require `?token=<session>` for upgrade.
- Always use `--insecure` with care if exposing on a network.

## Starting the dashboard from the agent (headless VPS, no local terminal)

When the user only has a browser (work computer, no local CLI) and Hermes runs on a VPS:

```bash
# 1) Stop any stale instance
hermes dashboard --stop

# 2) Start backgrounded on all interfaces (use --no-open because there's no browser on the VPS)
hermes dashboard --insecure --host 0.0.0.0 --no-open
```

Access: `http://<vps-ip>:9119`

If the agent spawns it via `terminal(background=true)`, verify it actually bound:
```bash
ss -tlnp | grep 9119
```

**Pitfall:** `hermes dashboard` without `--no-open` will try `xdg-open` on the remote and may hang/fail in a headless environment. Always add `--no-open` when starting from the agent on a VPS.

**Pitfall:** Port 9119 may already be in use by a zombie dashboard (e.g. from a prior crashed agent session). Always run `--stop` first, or kill the old PID manually with `kill -9 <PID>`.

**Pitfall:** `--insecure` enables non-localhost binding but also exposes the `.env` editor (API keys) to anyone who can reach port 9119. If the VPS has a firewall, restrict 9119 to your office IP.

- **Dashboard tab missing for a plugin**: check that `plugins/<name>/dashboard/dist/` exists and the manifest is valid JSON.
- **`--tui` tab crashes**: verify the Python `pty_bridge` module is importable and that the PTY websocket backend is running.
